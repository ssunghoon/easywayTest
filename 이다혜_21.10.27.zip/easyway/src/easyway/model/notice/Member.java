package easyway.model.notice;

public class Member {

}
