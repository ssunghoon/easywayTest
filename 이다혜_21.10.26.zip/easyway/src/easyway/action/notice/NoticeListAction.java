package easyway.action.notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import easyway.model.notice.Notice;
import easyway.model.notice.ListModel;
import easyway.service.NoticeService;

public class NoticeListAction implements NoticeAction {

	@Override
	public NoticeActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		NoticeActionForward forward = new NoticeActionForward();
		NoticeService service = NoticeService.getInstance();

		/* ListModel listModel = service.officeListService(request); */
		/* request.setAttribute("listModel", listModel); */
		
		forward.setRedirect(false);
		forward.setPath("/WEB-INF/notice/officeList.jsp");
		
		return forward;
	}

}
