package easyway.model;

public class Member {

}
