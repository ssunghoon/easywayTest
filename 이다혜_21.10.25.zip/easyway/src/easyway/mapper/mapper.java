package easyway.mapper;

public class mapper {

}
