package easyway.mapper;

import java.util.List;

import org.apache.ibatis.session.RowBounds;

import easyway.model.Notice;
import easyway.model.Search;

public interface NoticeMapper {
int addNotice(Notice notice);

List<Notice> officeList(Search search, RowBounds row);

Notice detailNotice(int ob_id);

int updateNotice(Notice notice);

int deleteNotice(int ob_id);

int countNotice(Search search);

int ob_viewUpdate(int ob_id);
}
