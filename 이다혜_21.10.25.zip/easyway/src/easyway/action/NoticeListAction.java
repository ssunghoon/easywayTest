package easyway.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import easyway.model.ListModel;

public class NoticeListAction implements NoticeAction {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		NoticeService service = NoticeService.getInstance();

		ListModel listModel = service.officeListService(request);
		request.setAttribute("listModel", listModel);
		
		forward.setRedirect(false);
		forward.setPath("/officeList.jsp");
		
		return forward;
	}

}
