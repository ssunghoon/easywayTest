package easyway.model.member;

public class Member {

}
