package easyway.service;

public class service {

}
